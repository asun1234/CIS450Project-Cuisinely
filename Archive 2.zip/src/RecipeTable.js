import React from "react";
import Checkbox from "@material-ui/core/Checkbox";


class RecipeTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tableRecipes: [],
            cart: [],
        }
        this.componentDidMount = this.componentDidMount.bind(this);
    }

updateCart(recipe, checked) {
    var recipesArr = this.state.recipes;
    const recipeId = recipe[1]
    recipesArr = recipesArr.filter((r) => r.id != recipeId)
    if (checked) {
        recipesArr.push({id: recipe[1], name: recipe[0]})
    }
    console.log('solen skinner')
    console.log("this.updateCart()", recipeId)

    this.setState({
        recipes: recipesArr
    })

    localStorage.setItem("recipeCart", JSON.stringify(this.state.recipes));
}

    componentDidMount() {
        const handleClick = (event) => {
            this.checked = event.target.checked;
        };
        fetch("http://localhost:8081/" + this.props.url, {
            method: "GET",
        })
            .then(res => res.json())
            .then(tenList => {
                if(!tenList) return;
                var arr= tenList.rows;
                var tenDivs = arr.map((recipe, i) => {
                    return (<tr>
                        <td>{i+1}</td>
                        <td>{recipe[0]}</td>
                        <td>{Number((recipe[1]).toFixed(1))}</td>
                        <td>{Number((recipe[2]).toFixed(2))}</td>
                        <td>
                            <Checkbox
                                key={i + 1}
                                color="primary"
                                checked={this.checked}
                                onClick={handleClick}
                                value={recipe[0]}
                                onChange={this.onChangeRec.bind(this)}
                            >
                            </Checkbox>
                        </td>
                    </tr>);
                });
                this.setState({
                    topten: tenDivs
                })
            })
    }